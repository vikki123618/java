package amshuhu;
// step 1.import package
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 //import org.apache.jasper.tagplugins.jstl.core.Out;

/**
 * Servlet implementation class loginervlet
 */
@WebServlet("/loginervlet")
public class loginervlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out=response.getWriter();
		try {
			//step 2.load and register the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			try {
				//step 3.create object(connection)
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/vikki","root","root");
			String n=request.getParameter("textName");
			String p=request.getParameter("textpwd");
			//step 4.create object of statement
			PreparedStatement ps=con.prepareStatement("select username from login where username=? and password=?;");
			ps.setString(1, n);
			ps.setString(2,p);
			//step 5.execute query
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				RequestDispatcher rd=request.getRequestDispatcher("welcome.jsp");
				rd.forward(request, response);
			}
			else
			{
				out.println("<font color=red size=18>Login Failed !!<br>");
				out.println("<a href=login.jsp>Try Again</a>");
			}
			
			
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		}
	}


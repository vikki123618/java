package registration.batabase;
//import package
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;

//student class import 
import registration.model.student;


public class studentdbc {
	//student is before class name
	public int studentRegister(student Student)throws ClassNotFoundException{
		//write query
		String INSERT_USER_SQL="INSERT INTO student"+"(studentId,studentName,studentDept,studentContact,studentAddress) VALUES"+"(?,?,?,?,?,?";
		
		//load and register the deiver
		Class.forName("com.mysql.jdbc.Driver");
		
		int result=0;
		
		//create object 
		try(Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student1","root","root");
		
		//statement
		PreparedStatement preparedStatement=con.prepareStatement(INSERT_USER_SQL)){
			
			preparedStatement.setInt(1, 1);
			preparedStatement.setString(2, Student.getStudentName());
			preparedStatement.setString(3, Student.getStudentDept());
			preparedStatement.setString(4, Student.getStudentContact());
			preparedStatement.setString(5, Student.getStudentAddress());
			
			
		} catch (SQLException e) {
			// process of Exception
			e.printStackTrace();
		}
		return result;
	}

}

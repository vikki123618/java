package registration.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import registration.batabase.studentdbc;
import registration.model.student;

/**
 * Servlet implementation class studentServlet
 */
@WebServlet("/studentServlet")
public class studentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//create object sudentdbc class name 
	private studentdbc studentDbc=new studentdbc();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public studentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		RequestDispatcher dispatchar=request.getRequestDispatcher("/WED-INF/view/studenthtml.jsp");
		dispatchar.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String studentId=request.getParameter("studentId");
		String studentName=request.getParameter("studentName");
		String studentDept=request.getParameter("studentDept");
		String studentContact=request.getParameter("studentContact");
		String studentAddress=request.getParameter("studentAdress");
		//create object student
		student std=new student();
		std.setStudentId(studentId);
		std.setStudentName(studentName);
		std.setStudentDept(studentDept);
		std.setStudentContact(studentContact);
		std.setStudentAddress(studentAddress);
		
		try{
			studentDbc.studentRegister(std);
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		RequestDispatcher dispatchar=request.getRequestDispatcher("/WED-INF/view/studentresult.jsp");
		dispatchar.forward(request, response);
	}

}

package registration.model;

public class student {
	private String studentId;
	private String studentName;
	//private String studentAge;
	private String studentDept;
	private String studentContact;
	private String studentAddress;
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
//	public String getStudentAge() {
//		return studentAge;
//	}
//	public void setStudentAge(String studentAge) {
//		this.studentAge = studentAge;
//}
	public String getStudentDept() {
		return studentDept;
	}
	public void setStudentDept(String studentDept) {
		this.studentDept = studentDept;
	}
	public String getStudentContact() {
		return studentContact;
	}
	public void setStudentContact(String studentContact) {
		this.studentContact = studentContact;
	}
	public String getStudentAddress() {
		return studentAddress;
	}
	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}
	
	}
	
	
	

